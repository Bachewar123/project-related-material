$(function(e) {
	'use strict'

	// Select2
	$('.select2').select2({
		minimumResultsForSearch: Infinity,
		width: '100%'
	});
	
});
