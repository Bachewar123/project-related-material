(function (e) {
    'use strict';
    $('#summernote').summernote({
        height:120,
    });
})();