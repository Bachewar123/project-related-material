<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from thepixelcurve.com/html/exvent/dest/index-4.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 29 Jun 2023 10:36:54 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Exvent - Event & Conference HTML5 Template</title>
    <meta name="robots" content="noindex, follow">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    <!-- CSS
	============================================ -->

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="assets/css/plugins/all.min.css">
    <link rel="stylesheet" href="assets/css/plugins/flaticon.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/aos.css">
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/plugins/lightbox.min.css">
    <link rel="stylesheet" href="assets/css/plugins/gijgo.min.css">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <!-- <link rel="stylesheet" href="assets/css/vendor/plugins.min.css">
    <link rel="stylesheet" href="assets/css/style.min.css"> -->

</head>

<body>

    <div class="main-wrapper">


        <!-- Preloader start -->
        <div id="preloader">
            <div class="preloader">
                <span></span>
                <span></span>
            </div>
        </div>
        <!-- Preloader End -->

        <!-- Header Start Transparent header  -->
        <div id="header" class="section exvent-header-2 exvent-header-4">

            <div class="container">

                <!-- Header Wrap Start  -->
                <div class="header-wrap">

                    <div class="header-logo">
                        <a href="index.php"><img src="assets\images\logo\Ofline.Social_Logo.jpg" alt="Ofline.Social_Logo" height="120vh" width="auto"></a>
                    </div>

                    <div class="header-menu d-none d-lg-block">
                        <ul class="main-menu">
                            <li class="active-menu">
                                <a href="index.php">Home</a>
                            </li>
                            <li>
                                <a href="#about">About Us</a>
                            </li>
                            <li>
                                <a href="#services">Services</a>
                            </li>
                            <li>
                                <a href="#register">Registration</a>
                            </li>
                            <li>
                                <a href="#faq">FAQ</a>
                            </li>
                            <li>
                                <a href="#contact">Get in Touch</a>
                            </li>
                        </ul>
                    </div>

                    <!-- Header Meta Start -->
                    <div class="header-meta">
                        <!-- Header Button Start -->
                        <!-- <div class="header-btn d-none d-xl-block">
                            <a class="btn btn-purple-2" href="pricing.html">Enquiry Now</a>
                        </div> -->
                        <!-- Header Button End -->

                        <!-- Header Toggle Start -->
                        <div class="header-toggle d-lg-none">
                            <button data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                        <!-- Header Toggle End -->
                    </div>
                    <!-- Header Meta End  -->

                </div>
                <!-- Header Wrap End  -->

            </div>
        </div>
        <!-- Header End -->

        <!-- Offcanvas Start-->
        <div class="offcanvas offcanvas-start" id="offcanvasExample">
            <div class="offcanvas-header">
                <!-- Offcanvas Logo Start -->
                <div class="offcanvas-logo">
                    <a href="index.html"><img src="assets/images/logo.png" alt=""></a>
                </div>
                <!-- Offcanvas Logo End -->
                <button type="button" class="close-btn" data-bs-dismiss="offcanvas"><i class="flaticon-close"></i></button>
            </div>

            <!-- Offcanvas Body Start -->
            <div class="offcanvas-body">
                <div class="offcanvas-menu">
                    <ul class="main-menu">
                        <li class="active-menu">
                            <a href="index.php">Home</a>
                        </li>
                        <li>
                            <a href="#about">About Us</a>
                        </li>
                        <li>
                            <a href="#services">Services</a>
                        </li>
                        <li>
                            <a href="#register">Registration</a>
                        </li>
                        <li>
                            <a href="#faq">FAQ</a>
                        </li>
                        <li>
                            <a href="#contact">Get in Touch</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Offcanvas Body End -->
        </div>
        <!-- Offcanvas End -->


        <!-- Hero Start -->
        <div class="section exvent-hero-section-04" style="background-image: url(assets/images/bg/hero_bg1.jpg);">
            <img class="shape-5 img-fluid" src="assets/images/shape/section_bottom_shape.png" alt="Shape">

            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="col-lg-7 col-md-8">
                        <div class="exvent-hero-title">
                            <!-- <h5 class="title-date" data-aos="fade-down" data-aos-delay="500">Register now</h5> -->
                            <h1 class="main-title" data-aos="fade-down" data-aos-delay="550">The Future Of Socializing Is</h1>
                            <p class="title-year" data-aos="fade-down" data-aos-delay="600">Here</p>
                            <button type="submit" class="submit_btn"><a href="#register">Register Now</a><i class="fa-solid fa-arrow-right"></i></button>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-8">
                        <div class="hero-form" style="background-image: url(assets/images/bg/form_bg.jpg);">
                            <h3 class="form-title text-center">Register now</h3>
                            <form action="#" class="exvent-form">
                                <div class="row gy-4">
                                    <div class="col-12">
                                        <div class="single-input">
                                            <input type="text" placeholder="Name">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="single-input">
                                            <input type="email" placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="single-input">
                                            <input type="tel" placeholder="Phone">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="single-input">
                                            <textarea name="Messege" placeholder="Messege"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-12 text-center">
                                        <button type="submit" class="submit_btn">Submit Registration Form</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Hero End -->

        <!-- About Start -->
        <div class="about-area-4 section-padding-09" id="about">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-thumbnail">
                            <img src="assets/images/about_img_3.jpg" alt="Thumbnail" class="about-thumb-1 img-fluid">
                            <img src="assets/images/about_img_4.jpg" alt="Thumbnail" class="about-thumb-2 img-fluid">
                            <img src="assets/images/shape/about_shape4.png" alt="Shape" class="thumbnail-shape img-fluid">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-title">
                            <div class="section-title">
                                <h2 class="sub-title">About us</h2>
                                <h2 class="title">Gather & Connect On Ofline Social's Plateform</h2>
                            </div>
                        </div>
                        <div class="about-content">
                            <div class="section-paragraph">
                                <p>Our mission is to inspire and empower individuals to break out of their comfort zones and take on life's adventures with a partner by their side.</p>
                                <p>Our unique social platform is designed to connect you with the perfect match for a personalised meet-up that is tailored to your interests, preferences, and goals.</p>
                                <p>Let us help you live life to the fullest</p>
                            </div>
                            <!-- <div class="about-event">
                                <img src="assets/images/calender-icon.png" alt="World" class="thumb">
                                <div class="content">
                                    <h5>When start</h5>
                                    <p>21th - 24th February 2022</p>
                                </div>
                            </div>
                            <div class="about-event">
                                <img src="assets/images/world-icon.png" alt="World" class="thumb">
                                <div class="content">
                                    <h5>Where to</h5>
                                    <p>Zhylianska St, 97б, Kyiv, Ukraine.</p>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->

        <!-- Event Agenda Start  -->
        <div class="event-agenda-area grey-bg section-padding-04" id="services">
            <img src="assets/images/shape/event_shape_h4_1.png" alt="shape" class="shape-1">
            <img src="assets/images/shape/event_shape_h4_2.png" alt="shape" class="shape-2">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title-wrap">
                            <div class="section-title text-center">
                                <h2 class="sub-title">services</h2>
                                <h3 class="title">Explore Our Offerings</h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="single-event text-center">
                            <a href="event-single.html" class="event-header">
                                <img src="assets\images\services\Coffee  Cafe Meet-up.jpg" alt="Coffee & Cafe Meet-up" class="event-thumb img-fluid">
                            </a>
                            <div class="event-body">
                                <img src="assets/images/shape/event_card_bg.png" alt="shape" class="event-body-shape img-fluid">
                                <a href="event-single.html">
                                    <h3 class="event-title">Coffee & Cafe Meet-up</h3>
                                </a>
                                <p class="event-desc">Join us for a delightful Coffee & Cafe meet-up, where you can savor aromatic brews, engage in stimulating conversations, and create meaningful connections in a cozy and inviting atmosphere.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-event text-center">
                            <a href="event-single.html" class="event-header">
                                <img src="assets\images\services\Club  Lounge Meet-up.jpg" alt="Club & Lounge Meet-up" class="event-thumb img-fluid">
                            </a>
                            <div class="event-body">
                                <img src="assets/images/shape/event_card_bg.png" alt="shape" class="event-body-shape img-fluid">
                                <a href="event-single.html">
                                    <h3 class="event-title">Club & Lounge Meet-up</h3>
                                </a>
                                <p class="event-desc">Experience the vibrant energy of our Club & Lounge meet-up, where you can unwind, socialize, and enjoy the pulsating beats, creating unforgettable moments in a stylish and lively setting.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-event text-center">
                            <a href="event-single.html" class="event-header">
                                <img src="assets\images\services\Yacht Meet-up.jpg" alt="Yacht Meet-up" class="event-thumb img-fluid">
                            </a>
                            <div class="event-body">
                                <img src="assets/images/shape/event_card_bg.png" alt="shape" class="event-body-shape img-fluid">
                                <a href="event-single.html">
                                    <h3 class="event-title">Yacht - Coming Up Soon</h3>
                                </a>
                                <p class="event-desc">Set sail with us on a luxurious Yacht meet-up, where you can indulge in breathtaking views, mingle with fellow enthusiasts, and create unforgettable memories amidst the serene beauty of the open waters.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Event Agenda End  -->

        <!-- Pricing Area Start -->
        <div class="pricing-area pricing-area-4 section-padding-04" id="register" style="background-image: url(assets/images/bg/price_bg_h4.jpg);">
            <img class="section-shape-bottom img-fluid" src="assets/images/shape/section_bottom_shape.png" alt="Shape">
            <div class="pricing-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-title-wrap">
                                <div class="section-title text-center">
                                    <h2 class="sub-title white-2">Register as</h2>
                                    <p class="title white">Thriving Digitally With Creative Authenticity</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-sm-7">
                            <div class="price-card text-center">
                                <!-- <img src="assets\images\shape\h3_hero_shape4.png" alt="Shape" class="price-card-shape img-fluid"> -->
                                <div class="price-header">
                                    <!-- <span class="price-plan">Basic Pass</span> -->
                                    <!-- <h3 class="price-ammount blue-text"><sup>$</sup>43</h3> -->
                                    <img src="assets\images\Business Partner.jpeg" alt="Business Partner">
                                </div>
                                <div class="price-body">
                                    <ul class="price-desc">
                                        <li>Event Management Tools</li>
                                        <li>Registration and Ticketing</li>
                                        <li>Customizable Event Pages</li>
                                        <li>Security and Privacy</li>
                                    </ul>
                                </div>
                                <div class="price-footer">
                                    <a href="pricing.html" class="btn price-btn btn-blue">Business Partner</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-7">
                            <div class="price-card text-center">
                                <!-- <img src="assets/images/shape/price_card_shape4.png" alt="Shape" class="price-card-shape img-fluid"> -->
                                <div class="price-header">
                                    <!-- <span class="price-plan">Premium Pass</span> -->
                                    <!-- <h3 class="price-ammount pink-text"><sup>$</sup>143</h3> -->
                                    <img src="assets\images\Memeber.jpg" alt="Memeber">
                                </div>
                                <div class="price-body">
                                    <ul class="price-desc">
                                        <li>Networking Opportunities</li>
                                        <li>Event Discounts</li>
                                        <li>Community Engagement</li>
                                        <li>Security and Privacy</li>
                                    </ul>
                                </div>
                                <div class="price-footer">
                                    <a href="pricing.html" class="btn price-btn">Subscriber / Member</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-7">
                            <div class="price-card text-center">
                                <!-- <img src="assets/images/shape/price_card_shape4.png" alt="Shape" class="price-card-shape img-fluid"> -->
                                <div class="price-header">
                                    <!-- <span class="price-plan">Platinam Pass</span> -->
                                    <!-- <h3 class="price-ammount orange-text"><sup>$</sup>243</h3> -->
                                    <img src="assets\images\venue partner.jpg" alt="Venue Partner">
                                </div>
                                <div class="price-body">
                                    <ul class="price-desc">
                                        <li>Venue Profile Management</li>
                                        <li>Collaboration with Event Professionals</li>
                                        <li>Showcase Venue Features</li>
                                        <li>Security and Privacy</li>
                                    </ul>
                                </div>
                                <div class="price-footer">
                                    <a href="pricing.html" class="btn price-btn btn-orange">Venue Partner</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Pricing Area End -->

        <!-- FAQ Area Start -->
        <div class="faq-area section-padding-06" id="faq">
            <img src="assets/images/bg/map_bg.png" alt="Map BG" class="bg-map img-fluid">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="section-title-wrap">
                            <div class="section-title text-center">
                                <h2 class="sub-title">FAQ's</h2>
                                <h2 class="title">Frequently Asked Quetions</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="accordion accordion-flush" id="faq_accordion">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="accordion_1">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                        Can price reducable?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="accordion_1" data-bs-parent="#faq_accordion">
                                    <div class="accordion-body">
                                        <p>We’re inviting the top creatives in the tech industry from all over the world to come learn, <br> grow, scrape their knees.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="accordion_2">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        How to purchase?
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="accordion_2" data-bs-parent="#faq_accordion">
                                    <div class="accordion-body">
                                        <p>We’re inviting the top creatives in the tech industry from all over the world to come learn, <br> grow, scrape their knees.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="accordion_3">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        Can i use for free ?
                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="accordion_3" data-bs-parent="#faq_accordion">
                                    <div class="accordion-body">
                                        <p>We’re inviting the top creatives in the tech industry from all over the world to come learn, <br> grow, scrape their knees.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="accordion_4">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                        How to get refund ?
                                    </button>
                                </h2>
                                <div id="collapseFour" class="accordion-collapse collapse" aria-labelledby="accordion_4" data-bs-parent="#faq_accordion">
                                    <div class="accordion-body">
                                        <p>We’re inviting the top creatives in the tech industry from all over the world to come learn, <br> grow, scrape their knees.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- FAQ Area End -->

        <!-- Contact Page Start -->
        <div class="contact-form-section section-padding-02" id="contact">
            <div class="container">
                <div class="row g-5 justify-content-between">
                    <div class="col-lg-5">
                        <div class="section-title-wrap">
                            <div class="section-title">
                                <h5 class="sub-title">Get In Touch</h5>
                                <h2 class="title">Contact With Us</h2>
                            </div>
                        </div>
                        <div class="single-contact">
                            <span class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </span>
                            <div class="contact-info">
                                <h4 class="contact-label">Our Location : </h4>
                                <p class="address">Mumbai, India</p>
                            </div>
                        </div>
                        <div class="single-contact">
                            <span class="contact-icon orange-color">
                            <i class="flaticon-phone-call"></i>
                        </span>
                            <div class="contact-info">
                                <h4 class="contact-label">24/7 Online</h4>
                                <a href="tel:+4581236572324" class="address">+91 123 456 789</a>
                            </div>
                        </div>
                        <div class="single-contact">
                            <span class="contact-icon blue-color">
                            <i class="far fa-envelope"></i>
                            </span>
                            <div class="contact-info">
                                <h4 class="contact-label">Email :</h4>
                                <a href="mailto:example@gmail.com" class="address">example@gmail.com</a>
                            </div>
                        </div>
                        <i class="fa-brands fa-instagram"></i>
                        <i class="fa-brands fa-facebook"></i>
                        <i class="fa-brands fa-linkedin"></i>
                        <i class="fa-brands fa-twitter"></i>
                        <i class="fa-brands fa-youtube"></i>
                    </div>
                    <div class="col-lg-6">
                        <div class="map-section">
                            <div class="map">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241316.67292289433!2d72.71636964480732!3d19.082502008346097!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1688188071122!5m2!1sen!2sin" allowfullscreen="" loading="lazy"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Contact Page Start -->

        <!-- Footer Section Start -->
        <div class="footer-section footer-section-4">
            <img src="assets/images/shape/footer_shape_1.png" alt="shape" class="footer-shape-1">
            <img src="assets/images/shape/footer_shape_2.png" alt="shape" class="footer-shape-2">
            <div class="container">
                
            </div>

            <!-- Footer Widget Area Start  -->
            <div class="footer-widgets-area">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-3 col-sm-6 col-8 text-sm-start text-center quick-action">
                            <div class="footer-widget">
                                <div class="logo-wrap text-center">
                                    <img src="assets\images\logo\Ofline.Social_Logo.jpg" alt="Logo" class="logo">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 col-8 text-sm-start text-center">
                            <div class="footer-widget">
                                <h4 class="widget-title">Quick action</h4>
                                <div class="widget-content">
                                    <ul>
                                        <li><a href="#" class="event-date">Home</a></li>
                                        <li><a href="#about" class="event-date">About</a></li>
                                        <li><a href="#services" class="event-date">Services</a></li>
                                        <li><a href="#registration" class="event-date">Registration</a></li>
                                        <li><a href="#faq">FAQ</a></li>
                                        <li><a href="#contact" class="event-date">Get in touch</a></li>
                                    </ul>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 col-8 text-sm-start text-center">
                            <div class="footer-widget">
                                <h4 class="widget-title">Contact Us</h4>
                                <div class="widget-content">
                                    <a href="tel:+91458654528" class="event-meta"><span><i class="flaticon-phone-call"></i></span>+91 123 456 789</a>
                                    <a href="mailto:info@example.com" class="event-meta"><span><i class="far fa-envelope-open"></i></span>example@gmail.com</a>
                                    <a href="contact.html" class="event-meta"><span><i class="fas fa-map-marker-alt"></i></span>Mumbai, India</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6 col-8 text-sm-start text-center">
                            <div class="footer-widget">
                                <h4 class="widget-title">Services</h4>
                                <div class="widget-content">
                                    <a href="#" class="footer-nav-item">Coffee And Cafe Meet-up</a>
                                    <a href="#" class="footer-nav-item">Club & Lounge Meet-up</a>
                                    <a href="#" class="footer-nav-item">Yacht - Coming Up Soon</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Widget Area End  -->


            <!-- Footer Copyright Start -->
            <div class="footer-copyright-area">
                <div class="container">
                    <div class="footer-copyright-wrap">
                        <div class="row align-items-center">
                            <div class="col-lg-12">
                                <!-- Footer Copyright Text Start -->
                                <div class="copyright-text text-center">
                                    <p>Copyright © 2023 <a href="index.php">Ofline Social</a> All Rights Reserved.</p>
                                </div>
                                <!-- Footer Copyright Text End -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer Copyright End -->
        </div>
        <!-- Footer Section End -->

        <!-- back to top start -->
        <div class="progress-wrap">
            <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
                <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
            </svg>
        </div>
        <!-- back to top end -->

    </div>

    <!-- JS
    ============================================ -->
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="assets/js/plugins/popper.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script>

    <!-- Plugins JS -->
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <script src="assets/js/plugins/aos.js"></script>
    <script src="assets/js/plugins/waypoints.min.js"></script>
    <script src="assets/js/plugins/back-to-top.js"></script>
    <script src="assets/js/plugins/jquery.counterup.min.js"></script>
    <script src="assets/js/plugins/appear.min.js"></script>
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/plugins/lightbox.min.js"></script>
    <script src="assets/js/plugins/gijgo.min.js"></script>


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->


    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>
</html>