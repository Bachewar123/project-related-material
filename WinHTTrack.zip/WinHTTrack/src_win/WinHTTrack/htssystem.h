// D�finition de la plate-forme utilis�e

// Sun Solaris .......... 0 
// Windows/95 ........... 1 
// Ibm 580 .............. 2

#define HTS_PLATFORM 1
#define HTS_ANALYSTE 1

// SHELL
//#define HTS_ANALYSTE 2


// Fin de la d�finition


